# What?
This includes patches for games such as Phantom Forces, making this module usable within those games. Just execute and enjoy!